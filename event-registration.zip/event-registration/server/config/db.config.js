module.exports = {
  HOST: "localhost",
  USER: "root",
  PASSWORD: "1234", // ← Replace this
  DB: "event_db",
  dialect: "mysql"
};
